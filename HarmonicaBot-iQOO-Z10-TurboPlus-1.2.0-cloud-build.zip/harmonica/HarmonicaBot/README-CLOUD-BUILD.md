# 不装 Android Studio，直接云端生成 APK

这个工程已经加入 GitHub Actions 自动构建。你不需要在手机或电脑安装 Android Studio、Android SDK 或 Gradle。

## 手机操作步骤

1. 在 GitHub 新建一个空的 Repository。
2. 把本项目里的 `harmonica/HarmonicaBot/` 目录中的**所有文件和文件夹**上传到仓库根目录。
3. 打开仓库的 `Actions` 页面。
4. 选择 `Build HarmonicaBot APK`。
5. 点 `Run workflow`。
6. 等待构建完成后，打开这次运行记录，在 `Artifacts` 中下载：
   `HarmonicaBot-iQOO-Z10-TurboPlus-debug`
7. 解压后得到 `app-debug.apk`，直接在 iQOO Z10 Turbo+ 安装。

如果 GitHub 提示 Actions 被禁用，在仓库的 Actions 页面启用允许工作流运行即可。

## 第一次安装

这是 debug APK，会使用 Android 的调试签名。安装时如果系统提示允许安装未知来源应用，需要按系统提示开启对应权限。

安装后：

`口琴自动演奏 → 开启无障碍服务 → 选择 MIDI → 套用 iQOO / 16:9 截图键位 → 进入游戏 → 校准 → 播放`

首次使用建议先校准一次，因为游戏自己的画面比例、显示设置或系统导航栏可能改变实际触摸区域。
