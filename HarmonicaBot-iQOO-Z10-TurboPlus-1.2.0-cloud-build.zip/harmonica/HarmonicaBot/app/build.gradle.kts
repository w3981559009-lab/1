plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android { namespace = "com.example.harmonicabot"; compileSdk = 35
    defaultConfig { applicationId = "com.example.harmonicabot"; minSdk = 24; targetSdk = 35; versionCode = 2; versionName = "1.2.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
}
