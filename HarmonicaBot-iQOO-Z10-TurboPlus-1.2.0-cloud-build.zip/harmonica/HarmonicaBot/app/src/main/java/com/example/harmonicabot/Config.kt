package com.example.harmonicabot

import android.graphics.PointF

data class Mod(val name: String, val semis: Int)

enum class PresetMode { CONTENT_16_9, FULL_SCREEN }

object Config {
    const val ROOT_MIDI = 60
    val KEY_OFFSETS = intArrayOf(0, 2, 4, 5, 7, 9, 11, 12)
    val MODS = listOf(Mod("升半音 ♯", +1), Mod("降半音 ♭", -1))

    // 原始截图：1536×864（16:9）。保存为归一化坐标，便于换屏幕。
    val SCREENSHOT_KEY_PRESET = listOf(
        PointF(290f / 1536f, 426f / 864f),
        PointF(427f / 1536f, 426f / 864f),
        PointF(564f / 1536f, 426f / 864f),
        PointF(701f / 1536f, 426f / 864f),
        PointF(837f / 1536f, 426f / 864f),
        PointF(974f / 1536f, 426f / 864f),
        PointF(1110f / 1536f, 426f / 864f),
        PointF(1246f / 1536f, 426f / 864f)
    )

    // iQOO Z10 Turbo+ 的官方规格为 2800×1260、144Hz；此处只用于布局换算。
    // 16:9 游戏画面在 20:9 屏幕中居中时，左右会各有约 280px 内容区偏移。
    const val REFERENCE_W = 1536f
    const val REFERENCE_H = 864f

    const val COUNTDOWN_SEC = 3
    const val MOD_LEAD_MS = 35L
    const val GAP_MS = 12L
    const val MIN_HOLD_MS = 25L
    const val MAX_HOLD_MS = 900L
    const val HOLD_RATIO = 0.85
    const val MIN_ONSET_GAP_MS = 70L
    const val MAX_STROKES = 18
    const val MAX_CHUNK_MS = 4000L
}
