package com.example.harmonicabot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/** Activity 和 Service 之间共享的当前曲谱 */
object Session {
    var title: String = ""
    var plan: List<PlayNote> = emptyList()
}

/** 键位坐标，存屏幕比例(0~1)，换分辨率也能用（但要同一个横/竖屏方向） */
class KeyLayout(val keys: List<PointF>, val mods: List<PointF?>)

class HarmonicaService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: HarmonicaService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val token = Any()
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var calib: FrameLayout? = null
    private var statusView: TextView? = null
    private var playing = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopPlay()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopPlay()
        removePanel()
        instance = null
        return super.onUnbind(intent)
    }

    // ───────────────────────── 悬浮控制条 ─────────────────────────

    private fun label(t: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(18, 12, 18, 12)
    }

    private fun rounded(color: Int, radius: Float = 18f): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius * resources.displayMetrics.density
        }

    fun showPanel() {
        if (panel != null) return

        val handle = label("☰ 口琴", 13f, 0xFFE8EDF5.toInt()).apply {
            background = rounded(0xFF171C25.toInt(), 18f)
        }
        val status = label(if (Session.title.isEmpty()) "未选曲" else "♪ ${Session.title}", 12f, 0xFF9BA7B8.toInt())
        statusView = status
        val play = label("▶", 17f).apply { background = rounded(0xFF2F7CF6.toInt(), 16f) }
        val stop = label("■", 16f).apply { background = rounded(0xFF252B35.toInt(), 16f) }
        val cal = label("⌖", 17f).apply { background = rounded(0xFF252B35.toInt(), 16f) }
        val close = label("×", 20f).apply { background = rounded(0xFF252B35.toInt(), 16f) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(0xEE0E1117.toInt())
            addView(handle, LinearLayout.LayoutParams(-1, 44))
            addView(status, LinearLayout.LayoutParams(-1, 40))
            val row = LinearLayout(this@HarmonicaService).apply {
                gravity = Gravity.CENTER
                addView(play, LinearLayout.LayoutParams(48, 48).apply { marginEnd = 6 })
                addView(stop, LinearLayout.LayoutParams(48, 48).apply { marginEnd = 6 })
                addView(cal, LinearLayout.LayoutParams(48, 48).apply { marginEnd = 6 })
                addView(close, LinearLayout.LayoutParams(48, 48))
            }
            addView(row)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 18
            y = 110
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        handle.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; downY = ev.rawY; startX = lp.x; startY = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (ev.rawX - downX).toInt()
                    lp.y = startY + (ev.rawY - downY).toInt()
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }
        play.setOnClickListener { onPlayClicked() }
        stop.setOnClickListener { stopPlay(); setStatus("已停止") }
        cal.setOnClickListener { startCalibration() }
        close.setOnClickListener { removePanel() }

        wm.addView(root, lp)
        panel = root
    }

    private fun removePanel() {
        stopPlay()
        panel?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        panel = null
        statusView = null
    }

    private fun setStatus(s: String) {
        statusView?.text = s
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ───────────────────────── 键位校准 ─────────────────────────

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun saveLayout(keys: List<PointF>, mods: List<PointF?>) {
        val o = JSONObject()
        val ka = JSONArray()
        keys.forEach { ka.put(JSONArray().put(it.x.toDouble()).put(it.y.toDouble())) }
        val ma = JSONArray()
        mods.forEach {
            if (it == null) ma.put(JSONObject.NULL) else ma.put(JSONArray().put(it.x.toDouble()).put(it.y.toDouble()))
        }
        o.put("keys", ka)
        o.put("mods", ma)
        getSharedPreferences("harmonica", Context.MODE_PRIVATE).edit().putString("layout", o.toString()).apply()
    }

    /**
     * 套用截图中的 1536×864 键位。
     * iQOO Z10 Turbo+ 横屏为 2800×1260（约 20:9），默认按 16:9 游戏内容区居中换算，
     * 这样不会把 16:9 截图的琴键横坐标直接拉伸到 20:9 屏幕两侧。
     */
    fun applyScreenshotPreset() {
        stopPlay()
        val (w, h) = screenSize()
        val aspect = w.toFloat() / h.toFloat()
        val contentW: Float
        val offsetX: Float
        if (aspect > 1.80f) {
            contentW = h * (16f / 9f)
            offsetX = (w - contentW) / 2f
        } else {
            contentW = w.toFloat()
            offsetX = 0f
        }
        val converted = Config.SCREENSHOT_KEY_PRESET.map {
            PointF((offsetX + it.x * contentW) / w, it.y)
        }
        saveLayout(converted, List(Config.MODS.size) { null })
        toast("已套用 16:9 → ${w}×${h} 键位换算")
    }

    private fun loadLayout(): KeyLayout? {
        val s = getSharedPreferences("harmonica", Context.MODE_PRIVATE).getString("layout", null) ?: return null
        return try {
            val o = JSONObject(s)
            val ka = o.getJSONArray("keys")
            val ma = o.getJSONArray("mods")
            val keys = (0 until ka.length()).map {
                val a = ka.getJSONArray(it)
                PointF(a.getDouble(0).toFloat(), a.getDouble(1).toFloat())
            }
            val mods = (0 until ma.length()).map {
                if (ma.isNull(it)) null else {
                    val a = ma.getJSONArray(it)
                    PointF(a.getDouble(0).toFloat(), a.getDouble(1).toFloat())
                }
            }
            if (keys.size == Config.KEY_OFFSETS.size && mods.size == Config.MODS.size) KeyLayout(keys, mods) else null
        } catch (e: Exception) {
            null
        }
    }

    private fun startCalibration() {
        if (calib != null) return
        stopPlay()
        val nKeys = Config.KEY_OFFSETS.size
        val steps = ArrayList<String>()
        for (i in 0 until nKeys) steps.add("点第 ${i + 1} 个音键（从最低音开始）")
        for (m in Config.MODS) steps.add("点修饰键「${m.name}」")

        val keyPts = ArrayList<PointF>()
        val modPts = ArrayList<PointF?>()
        val dots = ArrayList<PointF>()
        var idx = 0

        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB000E5FF.toInt() }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 32f
            textAlign = Paint.Align.CENTER
        }
        val root = object : FrameLayout(this) {
            override fun dispatchDraw(canvas: Canvas) {
                super.dispatchDraw(canvas)
                dots.forEachIndexed { i, p ->
                    canvas.drawCircle(p.x, p.y, 30f, dotPaint)
                    canvas.drawText("${i + 1}", p.x, p.y + 11f, textPaint)
                }
            }
        }
        root.setWillNotDraw(false)
        root.setBackgroundColor(0x55000000)

        val prompt = label("${steps[0]}（1/${steps.size}）", 18f).apply { setBackgroundColor(0xAA000000.toInt()) }
        val skip = label("跳过此键", 14f).apply { setBackgroundColor(0xAA000000.toInt()) }
        val cancel = label("取消", 14f).apply { setBackgroundColor(0xAA000000.toInt()) }
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        root.addView(prompt, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        root.addView(skip, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.START))
        root.addView(cancel, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END))

        fun finish(save: Boolean) {
            try { wm.removeView(root) } catch (_: Exception) {}
            calib = null
            if (save) {
                saveLayout(keyPts, modPts)
                toast("校准完成，可以播放了")
            }
        }

        fun step(p: PointF?, viewX: Float, viewY: Float) {
            if (p != null) dots.add(PointF(viewX, viewY))
            if (idx < nKeys) keyPts.add(p!!) else modPts.add(p)
            idx++
            if (idx >= steps.size) {
                finish(true)
            } else {
                prompt.text = "${steps[idx]}（${idx + 1}/${steps.size}）"
                root.invalidate()
            }
        }

        root.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_UP) {
                val (w, h) = screenSize()
                step(PointF(ev.rawX / w, ev.rawY / h), ev.x, ev.y)
            }
            true
        }
        skip.setOnClickListener {
            if (idx < nKeys) toast("音键不能跳过") else step(null, 0f, 0f)
        }
        cancel.setOnClickListener { finish(false) }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(root, lp)
        calib = root
    }

    // ───────────────────────── 播放调度 ─────────────────────────

    private class Stroke(val t: Long, val d: Long, val x: Float, val y: Float)
    private class Chunk(val t0: Long, val strokes: List<Stroke>)

    private fun onPlayClicked() {
        if (playing) {
            toast("正在播放")
            return
        }
        val layout = loadLayout()
        if (layout == null) {
            toast("请先点「校准键位」")
            return
        }
        if (Session.plan.isEmpty()) {
            toast("请先在 App 里选择 MIDI 曲谱")
            return
        }
        startPlay(layout)
    }

    /**
     * 把整首曲子预编译成若干"手势块"：每块把同时/相邻的按键打包成一个 GestureDescription，
     * 由系统负责块内的精确时序；块与块之间用 Handler 按绝对时间发送。
     * （dispatchGesture 会取消正在进行的手势，所以块之间必须留出松开间隔。）
     */
    private fun buildChunks(plan: List<PlayNote>, layout: KeyLayout): List<Chunk> {
        val (w, h) = screenSize()
        val base = plan.first().startMs - (Config.MOD_LEAD_MS + 65)
        val chunks = ArrayList<Chunk>()
        var cur = ArrayList<Stroke>()
        var curStart = 0L

        for ((i, n) in plan.withIndex()) {
            var missing = false
            for (b in Config.MODS.indices) {
                if ((n.mask and (1 shl b)) != 0 && layout.mods[b] == null) missing = true
            }
            if (missing) continue // 没校准的修饰键：这个音跳过

            val t = n.startMs - base
            val lead = if (n.mask != 0) Config.MOD_LEAD_MS else 0L
            val next = plan.getOrNull(i + 1)
            val nextLead = if (next != null && next.mask != 0) Config.MOD_LEAD_MS else 0L
            val room = if (next == null) Long.MAX_VALUE else (next.startMs - base) - nextLead - Config.GAP_MS - t
            val desired = (n.durMs * Config.HOLD_RATIO).toLong().coerceIn(Config.MIN_HOLD_MS, Config.MAX_HOLD_MS)
            val hold = maxOf(20L, minOf(desired, room))

            val ns = ArrayList<Stroke>()
            val kp = layout.keys[n.key]
            ns.add(Stroke(t, hold, kp.x * w, kp.y * h))
            for (b in Config.MODS.indices) {
                if ((n.mask and (1 shl b)) != 0) {
                    val mp = layout.mods[b] ?: continue
                    ns.add(Stroke(t - lead, hold + lead, mp.x * w, mp.y * h))
                }
            }

            val noteStart = t - lead
            if (cur.isNotEmpty() &&
                (cur.size + ns.size > Config.MAX_STROKES || t + hold - curStart > Config.MAX_CHUNK_MS)
            ) {
                chunks.add(Chunk(curStart, cur))
                cur = ArrayList()
            }
            if (cur.isEmpty()) curStart = noteStart
            cur.addAll(ns)
        }
        if (cur.isNotEmpty()) chunks.add(Chunk(curStart, cur))
        return chunks
    }

    private fun dispatch(c: Chunk) {
        val b = GestureDescription.Builder()
        for (s in c.strokes) {
            val p = Path().apply { moveTo(s.x, s.y) }
            b.addStroke(GestureDescription.StrokeDescription(p, maxOf(0L, s.t - c.t0), maxOf(1L, s.d)))
        }
        dispatchGesture(b.build(), null, null)
    }

    private fun startPlay(layout: KeyLayout) {
        val chunks = buildChunks(Session.plan, layout)
        if (chunks.isEmpty()) {
            toast("没有可播放的音符")
            return
        }
        playing = true
        val start = SystemClock.uptimeMillis() + Config.COUNTDOWN_SEC * 1000L
        setStatus("倒计时…")
        for (i in Config.COUNTDOWN_SEC downTo 1) {
            handler.postAtTime({ setStatus("$i …") }, token, start - i * 1000L)
        }
        handler.postAtTime({ setStatus("演奏中") }, token, start)
        for (c in chunks) {
            handler.postAtTime({ if (playing) dispatch(c) }, token, start + c.t0)
        }
        val last = chunks.last()
        val end = start + last.strokes.maxOf { it.t + it.d } + 300
        handler.postAtTime({
            playing = false
            setStatus("播放完毕")
        }, token, end)
    }

    fun stopPlay() {
        playing = false
        handler.removeCallbacksAndMessages(token)
    }
}
