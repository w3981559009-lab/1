package com.example.harmonicabot

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var info: TextView
    private lateinit var device: TextView
    private var tracks: List<MidiTrack> = emptyList()
    private var songTitle = ""

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) load(uri)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius.toInt()).toFloat() }

    private fun button(text: String, primary: Boolean = false, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = bg(if (primary) 0xFF2F7CF6.toInt() else 0xFF202632.toInt(), 16f)
        setPadding(dp(18), dp(4), dp(18), dp(4))
        minHeight = dp(52)
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(14, 17, 23)
        window.navigationBarColor = Color.rgb(14, 17, 23)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(28))
            background = bg(0xFF0E1117.toInt(), 0f)
        }

        val title = TextView(this).apply {
            text = "口琴自动演奏"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })

        val sub = TextView(this).apply {
            text = "HarmonicaBot · iQOO Z10 Turbo+ 适配版"
            textSize = 14f
            setTextColor(0xFF9BA7B8.toInt())
        }
        root.addView(sub, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20) })

        device = TextView(this).apply {
            text = "设备预设：iQOO Z10 Turbo+\n屏幕基准：2800 × 1260 · 144Hz\n键位：8 键 · 16:9 游戏画面自动换算"
            textSize = 14f
            setTextColor(0xFFE8EDF5.toInt())
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = bg(0xFF171C25.toInt(), 16f)
        }
        root.addView(device, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        root.addView(button("① 开启无障碍服务", true) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) })

        root.addView(button("② 选择 MIDI 曲谱 (.mid)") {
            picker.launch(arrayOf("audio/midi", "audio/mid", "audio/x-midi", "application/octet-stream"))
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) })

        root.addView(button("③ 套用 iQOO / 16:9 截图键位") {
            HarmonicaService.instance?.let { it.applyScreenshotPreset(); Toast.makeText(this@MainActivity, "已套用 8 键预设，可进入游戏微调", Toast.LENGTH_SHORT).show() }
                ?: Toast.makeText(this@MainActivity, "请先开启无障碍服务", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(10) })

        root.addView(button("④ 显示悬浮控制台") {
            HarmonicaService.instance?.showPanel()
                ?: Toast.makeText(this@MainActivity, "请先开启无障碍服务", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(18) })

        info = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFFB9C3D2.toInt())
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = bg(0xFF151A22.toInt(), 16f)
            text = "准备就绪\n\n建议流程：开启服务 → 选择 MIDI → 套用预设 → 进入游戏 → 校准键位 → 播放。"
        }
        root.addView(info, LinearLayout.LayoutParams(-1, -2))

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF0E1117.toInt())
            addView(root)
        }
        setContentView(scroll)
    }

    private fun load(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            tracks = MidiParser.parse(bytes)
            songTitle = uri.lastPathSegment?.substringAfterLast('/') ?: "曲谱"
            if (tracks.isEmpty()) { info.text = "没有找到音符"; return }
            val items = arrayListOf("合并全部轨道（每个起音取最高音）")
            for (t in tracks) {
                val avg = t.notes.map { it.pitch }.average().toInt()
                items.add("${t.name}｜${t.notes.size} 音｜平均音高 $avg")
            }
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("选择旋律轨道")
                .setItems(items.toTypedArray()) { _, which -> build(if (which == 0) tracks else listOf(tracks[which - 1])) }
                .show()
        } catch (e: Exception) { info.text = "读取失败：${e.message}" }
    }

    private fun build(selected: List<MidiTrack>) {
        val melody = Melody.skyline(selected)
        if (melody.isEmpty()) { info.text = "这个轨道里没有可用的音符"; return }
        val r = Mapper.fit(melody)
        Session.plan = r.notes
        Session.title = songTitle
        val seconds = (melody.last().startMs - melody.first().startMs) / 1000
        info.text = "曲谱：$songTitle\n\n旋律音符：${r.total}\n可演奏：${r.notes.size}\n无法映射：${r.dropped}\n整体移调：${r.shift} 半音\n时长：约 ${seconds} 秒\n\n进入游戏后，打开悬浮控制台即可播放。"
    }
}
