package com.example.harmonicabot

import kotlin.math.abs

data class Note(val startMs: Long, val durMs: Long, val pitch: Int)

/** key = 音键序号(0 起)，mask = 需要同时按住的修饰键位掩码 */
data class PlayNote(val startMs: Long, val durMs: Long, val key: Int, val mask: Int)

class MidiTrack(val name: String, val notes: List<Note>)

class FitResult(val notes: List<PlayNote>, val shift: Int, val dropped: Int, val total: Int)

/** 最小可用的标准 MIDI 文件(SMF)解析器：读音符、速度变化，忽略鼓通道 */
object MidiParser {
    fun parse(data: ByteArray): List<MidiTrack> {
        var pos = 0
        fun u8(): Int = data[pos++].toInt() and 0xFF
        fun u16(): Int {
            val a = u8()
            val b = u8()
            return (a shl 8) or b
        }
        fun u32(): Int {
            val a = u16()
            val b = u16()
            return (a shl 16) or b
        }
        fun vlq(): Int {
            var v = 0
            while (true) {
                val b = u8()
                v = (v shl 7) or (b and 0x7F)
                if ((b and 0x80) == 0) return v
            }
        }

        require(data.size > 14 && String(data, 0, 4, Charsets.ISO_8859_1) == "MThd") { "不是有效的 MIDI 文件" }
        pos = 4
        val headerLen = u32()
        u16() // format
        val trackCount = u16()
        val division = u16()
        require((division and 0x8000) == 0) { "暂不支持 SMPTE 时间码的 MIDI" }
        pos = 8 + headerLen

        class Raw(val s: Long, val e: Long, val pitch: Int)

        val tempos = ArrayList<Pair<Long, Int>>() // tick -> 微秒/四分音符
        val rawTracks = ArrayList<Pair<String, List<Raw>>>()

        repeat(trackCount) {
            if (pos + 8 > data.size) return@repeat
            val id = String(data, pos, 4, Charsets.ISO_8859_1)
            pos += 4
            val len = u32()
            val end = minOf(pos + len, data.size)
            if (id != "MTrk") {
                pos = end
                return@repeat
            }
            var tick = 0L
            var running = 0
            var name = ""
            val open = HashMap<Int, Long>()
            val raws = ArrayList<Raw>()
            while (pos < end) {
                tick += vlq()
                var st = u8()
                if (st < 0x80) {
                    pos--
                    st = running
                } else if (st < 0xF0) {
                    running = st
                }
                if (st == 0xFF) {
                    val type = u8()
                    val l = vlq()
                    if (type == 0x51 && l == 3) {
                        val a = u8()
                        val b = u8()
                        val c = u8()
                        tempos.add(tick to ((a shl 16) or (b shl 8) or c))
                    } else {
                        if (type == 0x03 && pos + l <= data.size) name = String(data, pos, l, Charsets.UTF_8)
                        pos += l
                    }
                } else if (st == 0xF0 || st == 0xF7) {
                    val l = vlq()
                    pos += l
                } else {
                    val cmd = st and 0xF0
                    val ch = st and 0x0F
                    val d1 = u8()
                    val d2 = if (cmd == 0xC0 || cmd == 0xD0) 0 else u8()
                    if (cmd == 0x90 && d2 > 0) {
                        open[ch * 128 + d1] = tick
                    } else if (cmd == 0x80 || cmd == 0x90) {
                        val s = open.remove(ch * 128 + d1)
                        if (s != null && ch != 9) raws.add(Raw(s, tick, d1))
                    }
                }
            }
            rawTracks.add(name to raws)
            pos = end
        }

        tempos.sortBy { it.first }
        if (tempos.isEmpty() || tempos[0].first > 0L) tempos.add(0, 0L to 500000)
        val msAt = DoubleArray(tempos.size)
        for (i in 1 until tempos.size) {
            msAt[i] = msAt[i - 1] +
                (tempos[i].first - tempos[i - 1].first).toDouble() * tempos[i - 1].second / division / 1000.0
        }
        fun toMs(t: Long): Long {
            var i = tempos.size - 1
            while (i > 0 && tempos[i].first > t) i--
            return (msAt[i] + (t - tempos[i].first).toDouble() * tempos[i].second / division / 1000.0).toLong()
        }

        val result = ArrayList<MidiTrack>()
        rawTracks.forEachIndexed { i, (name, raws) ->
            if (raws.isNotEmpty()) {
                val notes = raws.map {
                    val s = toMs(it.s)
                    Note(s, maxOf(1L, toMs(it.e) - s), it.pitch)
                }.sortedBy { it.startMs }
                result.add(MidiTrack(if (name.isBlank()) "轨道 ${i + 1}" else name, notes))
            }
        }
        return result
    }
}

/** 把多轨/和弦的曲子压成单旋律(每个起音取最高音)，并去掉过密的音 */
object Melody {
    fun skyline(tracks: List<MidiTrack>): List<Note> {
        val all = tracks.flatMap { it.notes }.sortedBy { it.startMs }
        val grouped = ArrayList<Note>()
        var i = 0
        while (i < all.size) {
            var best = all[i]
            var j = i + 1
            while (j < all.size && all[j].startMs - all[i].startMs < 30) {
                if (all[j].pitch > best.pitch) best = all[j]
                j++
            }
            grouped.add(best)
            i = j
        }
        val out = ArrayList<Note>()
        for (n in grouped) {
            val last = out.lastOrNull()
            if (last == null || n.startMs - last.startMs >= Config.MIN_ONSET_GAP_MS) out.add(n)
        }
        return out.mapIndexed { idx, n ->
            val next = out.getOrNull(idx + 1)
            if (next != null && n.startMs + n.durMs > next.startMs) n.copy(durMs = next.startMs - n.startMs) else n
        }
    }
}

/** 指法映射：找出整体移调量，并为每个音选"用修饰键最少"的按法 */
object Mapper {
    /** 可演奏的音高 -> (音键序号, 修饰键掩码) */
    val table: Map<Int, Pair<Int, Int>> by lazy {
        val m = HashMap<Int, Pair<Int, Int>>()
        for (k in Config.KEY_OFFSETS.indices) {
            for (mask in 0 until (1 shl Config.MODS.size)) {
                var p = Config.ROOT_MIDI + Config.KEY_OFFSETS[k]
                for (b in Config.MODS.indices) {
                    if ((mask and (1 shl b)) != 0) p += Config.MODS[b].semis
                }
                val old = m[p]
                if (old == null || Integer.bitCount(mask) < Integer.bitCount(old.second)) m[p] = k to mask
            }
        }
        m
    }

    private class Placed(val f: Pair<Int, Int>, val cost: Double)

    private fun place(p0: Int, lo: Int, hi: Int): Placed? {
        var p = p0
        var folds = 0
        var guard = 0
        while (p > hi && guard++ < 12) { p -= 12; folds++ }
        while (p < lo && guard++ < 24) { p += 12; folds++ }
        val exact = table[p]
        if (exact != null) return Placed(exact, folds * 0.3 + Integer.bitCount(exact.second) * 0.1)
        for (d in intArrayOf(-1, 1)) { // 音阶缺口：找相邻半音近似
            val f = table[p + d]
            if (f != null) return Placed(f, folds * 0.3 + 1.0 + Integer.bitCount(f.second) * 0.1)
        }
        return null
    }

    fun fit(notes: List<Note>): FitResult {
        val lo = table.keys.minOrNull() ?: 0
        val hi = table.keys.maxOrNull() ?: 0
        var bestShift = 0
        var bestCost = Double.MAX_VALUE
        for (s in -12..12) {
            var c = abs(s) * 0.001
            for (n in notes) c += place(n.pitch + s, lo, hi)?.cost ?: 3.0
            if (c < bestCost) {
                bestCost = c
                bestShift = s
            }
        }
        val out = ArrayList<PlayNote>()
        var dropped = 0
        for (n in notes) {
            val pl = place(n.pitch + bestShift, lo, hi)
            if (pl == null) dropped++ else out.add(PlayNote(n.startMs, n.durMs, pl.f.first, pl.f.second))
        }
        return FitResult(out, bestShift, dropped, notes.size)
    }
}
